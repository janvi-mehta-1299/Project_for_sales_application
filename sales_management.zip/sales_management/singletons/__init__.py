from singletons.db import db  # noqa: F401
