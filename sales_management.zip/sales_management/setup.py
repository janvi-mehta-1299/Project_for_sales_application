export DOCKER_BUILDKIT=1
export COMPOSE_DOCKER_CLI_BUILD=1
export BUILDKIT_PROGRESS=plain

# Start the app
docker-compose up --build app

# Create the database tables with
docker exec -it twtest flask db init

# You can run the tests with
docker exec -it twtest pytest