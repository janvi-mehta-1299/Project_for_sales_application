from singletons import db
from app.models.sale import Sale

def add_sale(total_cost, commission_rate, tax_rate,description):
    print("adding sale data into db")
    db.session.add(Sale(
        total_price=total_cost,
        commission_rate=commission_rate,
        tax_rate=tax_rate,
        description = description,
    ))
    print("added sale data into db")
    db.session.commit()
    print("commiting")


