## TeamWeb Technical Test

This is the TeamWeb technical test.

Please open a pull request with your changes when ready.

Do not use AI to complete the test for you.

### Setup

To start the app run:

```shell
# Enable BuildKit
export DOCKER_BUILDKIT=1
export COMPOSE_DOCKER_CLI_BUILD=1
export BUILDKIT_PROGRESS=plain

# Start the app
docker-compose up --build app

# Create the database tables with
docker exec -it twtest flask db init

# You can run the tests with
docker exec -it twtest pytest
```

This will run the flask app locally on port 5123 and the database container on port 3308.  
These can be customised by setting `FLASK_PORT` and `DB_PORT`.

Once started open [http://127.0.0.1:5123/](http://127.0.0.1:5123/) for the task details.

### Accessing the database

To access the database run this after starting the app:

```shell
docker exec -it twtest_db mysql -ulocal -ppassword twtest -A
```
