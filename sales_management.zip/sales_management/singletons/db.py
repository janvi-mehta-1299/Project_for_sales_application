# Singleton of the DBConnection() class
# Each app should import db and call db.init_app(app)

from common.database import DBConnection
db = DBConnection()
