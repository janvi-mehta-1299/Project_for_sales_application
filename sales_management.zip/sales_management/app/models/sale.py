from sqlalchemy import Column, Numeric,Text
from common.database.models import TableBase


class Sale(TableBase):
    total_price = Column(Numeric(15))
    tax_rate = Column(Numeric(5))
    commission_rate = Column(Numeric(5))
    description = Column(Text)
