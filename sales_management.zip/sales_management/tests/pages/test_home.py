def test_page_loads(client):
    response = client.get("/")
    assert b"<h1>TeamWeb Technical Test</h1>" in response.data
